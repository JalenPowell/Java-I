/**
 *@author Jalen Powell
 *@version August 26,2019
 */
public class StudentInfo {
/**
*This is some info about me and my class experience.
*Prints my name and previous computer courses.
*@param args Command line arguments (not used)
*/
   public static void main(String[] args) {
   
      // Prints my name and courses
      System.out.println("Name: Jalen Powell");
      System.out.println("Previous Computer Courses:");
      System.out.println("Summerbridge Java Intro Class");
   
   
   }

}