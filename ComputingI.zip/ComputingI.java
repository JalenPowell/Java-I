/**
 * This is Fundamentals of Computing I.
 *
 *@author Jalen Powell
 *@version August 25, 2019
 */
public class ComputingI {
   /**
    *Prints course infomation to std output.
    *
    *@param args Command line arguments (not used)
    */ 
   public static void main(String[] args) {
      
      // print course description
      System.out.println("This course provides an introdution to Java and ");
      System.out.println("object-oriented programming.");
      
      // print more course description
      System.out.println("The course also introduces the basics of software"
       + "development.");
      
   }
}